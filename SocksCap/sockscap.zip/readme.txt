Sockscap32 V2.40

This program is a freeware to make your programs support socks proxy.

How to use sockscap:
http://www.socksproxychecker.com/sockscap.html

You should check the socks proxy by Socks Proxy Checker before using it:
http://www.socksproxychecker.com
