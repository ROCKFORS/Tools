---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

Be sure to check the existing issues (both open and closed!), and make sure you are running the latest version of Guake.

For how to run the latest Guake in your computer, please refer to [Install from source](https://guake.readthedocs.io/en/latest/user/installing.html#install-from-source).

---------------------------------------

Please use [FeatHub](https://feathub.com/Guake/guake) to fill-up a feature request.

This allow us to spot directly which are the most requested features.

