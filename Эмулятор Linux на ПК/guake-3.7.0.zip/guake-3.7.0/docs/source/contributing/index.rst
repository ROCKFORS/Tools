=====================
Contributing to Guake
=====================

.. toctree::
    :caption: Contributing Guide
    :maxdepth: 2

    basic
    dev_env
    hacking
    packaging
