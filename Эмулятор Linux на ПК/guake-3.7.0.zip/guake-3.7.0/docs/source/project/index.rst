Project information
===================

.. toctree::
    :caption: Guake Documentation
    :maxdepth: 2

    history
    release_notes
    license
