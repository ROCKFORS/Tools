===============
 Release Notes
===============

This page lists information about new features, bugfixes, translation update of all
released and unreleased versions of Guake.

This page has been automatically generated, using
`reno <https://docs.openstack.org/reno/latest/>`_ tool.

.. release-notes::
    :branch: master
    :earliest-version: 3.0.0.a4
