User Manual
===========

.. toctree::
    :caption: Guake User Manual
    :maxdepth: 2

    whatisguake
    features
    installing
    cli
    dbus
    faq
    gtk3
