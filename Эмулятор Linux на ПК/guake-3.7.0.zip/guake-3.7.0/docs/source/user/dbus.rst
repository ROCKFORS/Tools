=================
 D-Bus Interface
=================

TBD: Describe the DBus interface, with message, how to use it. Recall how to send guake toggle
command.
