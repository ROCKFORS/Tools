========================
 Command Line Arguments
========================

Here is the command line interface Guake provides:

.. program-output:: guake --help
