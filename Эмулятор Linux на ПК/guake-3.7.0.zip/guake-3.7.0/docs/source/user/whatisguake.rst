==============
What is Guake?
==============

Guake is a powerful drop-down terminal, accessible by a simple hotkey. It has been designed to be
the swiss knife of any developer willing to increase its productivity.

Alternatives to Guake
=====================

Here are some of the best terminals avaiable on the Linux environments that bring similar features
of Guake:

- `Tilda <https://github.com/lanoxx/tilda/>`_
- `Tilix <https://github.com/gnunn1/tilix>`_
- `Yakuake <https://www.kde.org/applications/system/yakuake/>`_ (For the KDE)
- `GNOME Terminal <https://wiki.gnome.org/Apps/Terminal>`_
- `Terminator <http://gnometerminator.blogspot.com/>`_
