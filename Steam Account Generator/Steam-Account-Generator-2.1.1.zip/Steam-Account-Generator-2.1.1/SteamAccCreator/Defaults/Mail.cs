﻿namespace SteamAccCreator.Defaults
{
    public partial class Mail
    {
        public const string MAILBOX_ADDRESS = "https://newemailsrv.now.sh/";

        public const int COUNT_OF_CHECKS_MAIL_USER = 120;
        public const int COUNT_OF_CHECKS_MAIL_AUTO = 5;
    }
}
