﻿using System;

namespace SteamAccCreator.Defaults
{
    public partial class Web
    {
        public const string USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0";
    }
}
