﻿namespace SteamAccCreator.Enums
{
    public enum CaptchaService
    {
        None = -1,
        Captchasolutions,
        RuCaptcha,
        Module
    }
}
