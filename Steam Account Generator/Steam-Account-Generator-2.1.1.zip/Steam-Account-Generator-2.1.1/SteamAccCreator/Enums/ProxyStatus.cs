﻿namespace SteamAccCreator.Enums
{
    public enum ProxyStatus
    {
        Unknown,
        Working,
        Broken
    }
}
