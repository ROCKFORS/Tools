﻿using System;

namespace SteamAccCreator.Models
{
    [Serializable]
    public class MailConfig
    {
        public bool Random { get; set; }
        public string Value { get; set; }
    }
}
