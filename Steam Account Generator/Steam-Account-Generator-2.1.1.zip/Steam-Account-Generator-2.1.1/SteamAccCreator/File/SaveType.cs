﻿namespace SteamAccCreator.File
{
    public enum SaveType
    {
        PlainTxt,
        FormattedTxt,
        KeepassCsv
    }
}
