﻿namespace SteamAccCreator.Web.Updater.Enums
{
    public enum UpdateChannelEnum
    {
        Stable,
        DevRelease
    }
}
