﻿namespace SteamAccCreator.Web.Steam
{
    public partial class SteamDefaultUrls
    {
        public const string TF = STORE_BASE + "twofactor/";
        public const string TF_MANAGE = TF + "manage";
        public const string TF_MANAGE_ACTION = TF + "manage_action";
    }
}
