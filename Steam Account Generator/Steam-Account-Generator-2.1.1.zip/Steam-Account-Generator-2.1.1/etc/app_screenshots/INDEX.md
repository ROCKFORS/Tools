# Screenshots

![tab:settings](/etc/app_screenshots/default/settings.png)
![tab:profile](/etc/app_screenshots/default/profile.png)
![tab:captcha](/etc/app_screenshots/default/captcha.png)
![tab:file_writing](/etc/app_screenshots/default/file_writing.png)
![tab:proxy](/etc/app_screenshots/default/proxy.png)
![tab:modules](/etc/app_screenshots/default/modules.png)
![tab:updates](/etc/app_screenshots/default/updates.png)
![tab:about](/etc/app_screenshots/default/about.png)

## Some screenshots while app is working

![tab:ww:settings](/etc/app_screenshots/settings.png)

### Yeah! It's joining to groups
![tab:ww:groups_proof](/etc/app_screenshots/groups_proof.png)