﻿namespace SampleModule.Models
{
    public class CaptchaConfig
    {
        public string ApiKey { get; set; } = "";
    }
}
