﻿namespace SACModuleBase
{
    public interface ISACHandlerUserAgent : ISACBase
    {
        string GetUserAgent();
    }
}
