﻿namespace SACModuleBase.Enums
{
    public enum ProxyType
    {
        Unknown,
        Http,
        Https,
        Socks4,
        Socks5
    }
}
